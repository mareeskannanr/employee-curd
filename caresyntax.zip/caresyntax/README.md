* goto project root folder in the command prompt and run the following command 'mvn clean install'

* ensure system installed with maven 3.5.4 above if build fail

* access application through the url http://localhost:1000/

* port can be changed in application.properties file 'server.port'

* ui folder contains source code for front-end

* screenshots folder contains screenshots taken in my machine while performing testing
