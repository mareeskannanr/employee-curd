package com.study.scheduling.app.controller;

import com.study.scheduling.app.exception.AppException;
import com.study.scheduling.app.model.Patient;
import com.study.scheduling.app.service.AppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api")
public class AppRestCtrl {

    @Autowired
    private AppService appService;

    @GetMapping("/rooms")
    public ResponseEntity getAllRooms() {
        return ResponseEntity.ok(appService.getAllRooms());
    }

    @GetMapping("/doctors")
    public ResponseEntity getAllDoctors() {
        return ResponseEntity.ok(appService.getAllDoctors());
    }

    @PostMapping("/patient")
    public ResponseEntity savePatient(@Valid @RequestBody Patient patient) throws AppException {
        return ResponseEntity.status(HttpStatus.CREATED).body(appService.savePatient(patient));
    }

}
