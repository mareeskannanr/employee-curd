package com.study.scheduling.app.model;

import com.study.scheduling.app.utils.AppConstants;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "rooms")
@Data
@NoArgsConstructor
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotEmpty(message = AppConstants.NAME_REQUIRED)
    @Column(unique = true)
    private String name;

    public Room(String name) {
        this.name = name;
    }
}
