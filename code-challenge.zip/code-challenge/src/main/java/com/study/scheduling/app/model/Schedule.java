package com.study.scheduling.app.model;

import com.study.scheduling.app.utils.AppConstants;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Entity
@Table(name = "study_schedules")
@Data
@NoArgsConstructor
public class Schedule {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @OneToOne
    @JoinColumn(name="study_id")
    @NotNull(message = AppConstants.STUDY_REQUIRED)
    private Study study;

    @OneToMany
    private Set<Doctor> doctors;

    @OneToOne
    @JoinColumn(name="room_id")
    @NotNull(message = AppConstants.PATIENT_ID_REQUIRED)
    private Room room;
}
