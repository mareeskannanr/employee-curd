package com.study.scheduling.app.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.study.scheduling.app.utils.AppConstants;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "studies")
@Data
@NoArgsConstructor
public class Study {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "patient_id")
    @NotNull(message = AppConstants.PATIENT_ID_REQUIRED)
    private Patient patient;

    @NotBlank(message = AppConstants.DESCRIPTION_REQUIRED)
    private String description;

    @NotNull(message = AppConstants.STATUS_REQUIRED)
    @Enumerated(value = EnumType.STRING)
    private Status status;

    @NotNull(message = AppConstants.STATUS_REQUIRED)
    @Column(name = "planned_start_time")
    @JsonSerialize(using = ToStringSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime plannedStartTime;

    @Column(name = "estimated_end_time")
    @JsonSerialize(using = ToStringSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime estimatedEndTime;

}
