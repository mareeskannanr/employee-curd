package com.study.scheduling.app.repository;

import com.study.scheduling.app.model.StudySchedule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScheduleRepository extends JpaRepository<StudySchedule, Long> {}
