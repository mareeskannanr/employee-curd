package com.study.scheduling.app.service;

import com.study.scheduling.app.model.Doctor;
import com.study.scheduling.app.model.Patient;
import com.study.scheduling.app.model.Room;

import java.util.List;

public interface AppService {

    List<Room> getAllRooms();

    List<Doctor> getAllDoctors();

    Patient savePatient(Patient patient);
}
