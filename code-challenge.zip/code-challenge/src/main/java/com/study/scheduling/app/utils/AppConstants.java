package com.study.scheduling.app.utils;

public class AppConstants {
    public static final String INTERNAL_SERVER_ERROR_MSG = "Sorry, something went wrong!";
    public static final String INVALID_POST_MSG = "object contains invalid data.";
    public static final String NAME_REQUIRED = "name is required.";
}