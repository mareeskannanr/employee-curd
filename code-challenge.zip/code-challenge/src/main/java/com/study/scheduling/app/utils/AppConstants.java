package com.study.scheduling.app.utils;

public class AppConstants {
    public static final String INTERNAL_SERVER_ERROR_MSG = "Sorry, something went wrong!";
    public static final String INVALID_POST_MSG = "object contains invalid data.";
    public static final String NAME_REQUIRED = "name is required.";
    public static final String STATUS_REQUIRED = "status is required.";
    public static final String DESCRIPTION_REQUIRED = "description is required.";
    public static final String PATIENT_ID_REQUIRED = "patient is required.";
    public static final String STUDY_REQUIRED = "patient is required.";
}