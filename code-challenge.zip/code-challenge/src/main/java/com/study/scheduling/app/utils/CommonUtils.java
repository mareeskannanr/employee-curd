package com.study.scheduling.app.utils;

import com.study.scheduling.app.model.Doctor;
import com.study.scheduling.app.model.Room;
import com.study.scheduling.app.repository.DoctorRepository;
import com.study.scheduling.app.repository.RoomRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonUtils {

    private final static Logger logger = LoggerFactory.getLogger(CommonUtils.class);


    public static void setupRooms(RoomRepository roomRepository) {
        roomRepository.save(new Room("Room No.1"));
        roomRepository.save(new Room("Room No.2"));
        roomRepository.save(new Room("Room No.3"));
        roomRepository.save(new Room("Room No.4"));
        roomRepository.save(new Room("Room No.5"));
        logger.debug("Rooms Data Setup Done!");
    }

    public static void setupDoctors(DoctorRepository doctorRepository) {
        doctorRepository.save(new Doctor("Dr. Marry"));
        doctorRepository.save(new Doctor("Dr. Ani"));
        doctorRepository.save(new Doctor("Dr. Mathews"));
        doctorRepository.save(new Doctor("Dr. John"));
        doctorRepository.save(new Doctor("Dr. Paul"));
        logger.debug("Doctors Data Setup Done!");
    }



}
