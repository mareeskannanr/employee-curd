package com.study.scheduling.app;

import com.study.scheduling.app.utils.AppConstants;
import com.study.scheduling.app.utils.TestUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void getAllRooms() throws Exception {
		MvcResult result = mockMvc.perform(get("/api/rooms")).andReturn();
		assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());

		JSONArray resultArray = new JSONArray(result.getResponse().getContentAsString());
		assertEquals(5, resultArray.length());
	}

	@Test
	public void getAllDoctors() throws Exception {
		MvcResult result = mockMvc.perform(get("/api/doctors")).andReturn();
		assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());

		JSONArray resultArray = new JSONArray(result.getResponse().getContentAsString());
		assertEquals(5, resultArray.length());
	}

	@Test
	public void saveEmptyPatient() throws Exception {
		MockHttpServletResponse response = TestUtils.postObject(mockMvc, "{}");
		assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());

		JSONArray resultArray = new JSONArray(response.getContentAsString());
		assertEquals(1, resultArray.length());
		assertEquals(AppConstants.NAME_REQUIRED, resultArray.getString(0));
	}

	@Test
	public void savePatientWithEmptyName() throws Exception {
		String patient ="{\"name\": \"    \"}";
		MockHttpServletResponse response = TestUtils.postObject(mockMvc, patient);
		assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());

		JSONArray resultArray = new JSONArray(response.getContentAsString());
		assertEquals(1, resultArray.length());
		assertEquals(AppConstants.NAME_REQUIRED, resultArray.getString(0));
	}

	@Test
	public void savePatientWithWrongValues() throws Exception {
		String patient = "{\"name\": \"Sam\", \"sex\": \"bbb\", \"dob\": \"aaa\"}";
		MockHttpServletResponse response = TestUtils.postObject(mockMvc, patient);
		assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());

		JSONArray resultArray = new JSONArray(response.getContentAsString());
		assertEquals(1, resultArray.length());
		assertEquals(AppConstants.INVALID_POST_MSG, resultArray.getString(0));
	}

	@Test
	public void savePatientWithCorrectValues() throws Exception {
		JSONObject patient = new JSONObject("{\"name\": \"Sam\", \"sex\": \"Male\", \"dob\": \"1990-05-26\"}");
		MockHttpServletResponse response = TestUtils.postObject(mockMvc, patient.toString());
		assertEquals(HttpStatus.CREATED.value(), response.getStatus());

		JSONObject result = new JSONObject(response.getContentAsString());
		assertEquals(patient.get("name"), result.get("name"));
		assertEquals(patient.get("sex"), result.get("sex"));
		assertEquals(patient.get("dob"), result.get("dob"));
	}

}
