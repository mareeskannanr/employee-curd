package com.study.scheduling.app.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.study.scheduling.app.model.Patient;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

public class TestUtils {

    private static final String POST_PATIENT_URL = "/api/patient";
    private static final Patient patient = new Patient();
    public static final ObjectMapper mapper = new ObjectMapper();

    public static MockHttpServletResponse postObject(MockMvc mockMvc, String data) throws Exception {
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post(POST_PATIENT_URL)
                .accept(MediaType.APPLICATION_JSON).content(data)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        return result.getResponse();
    }


}
