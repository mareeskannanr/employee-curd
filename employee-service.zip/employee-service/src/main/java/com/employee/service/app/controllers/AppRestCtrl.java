package com.employee.service.app.controllers;


import com.employee.service.app.models.Department;
import com.employee.service.app.models.Employee;
import com.employee.service.app.services.EmployeeService;
import com.employee.service.app.utils.AppConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.UUID;

@RestController
@RequestMapping(AppConstants.API)
public class AppRestCtrl {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping(AppConstants.DEPARTMENT_URL)
    public ResponseEntity saveDepartment(@Valid @RequestBody Department department) {
        return ResponseEntity.status(HttpStatus.CREATED).body(employeeService.saveDepartment(department));
    }

    @PostMapping(AppConstants.EMPLOYEE_URL)
    public ResponseEntity createEmployee(@Valid @RequestBody Employee employee) {
        return ResponseEntity.status(HttpStatus.CREATED).body(employeeService.saveEmployee(employee));
    }

    @PutMapping(AppConstants.EMPLOYEE_URL)
    public ResponseEntity updateEmployee(@Valid @RequestBody Employee employee) {
        return ResponseEntity.ok(employeeService.saveEmployee(employee));
    }

    @GetMapping(AppConstants.EMPLOYEE_ID_URL)
    public ResponseEntity getEmployeeById(@PathVariable(AppConstants.UUID) UUID uuid) {
        return ResponseEntity.ok(employeeService.getEmployeeById(uuid));
    }

    @DeleteMapping(AppConstants.EMPLOYEE_ID_URL)
    public ResponseEntity deleteEmployeeById(@PathVariable(AppConstants.UUID) UUID uuid) {
        return ResponseEntity.noContent().build();
    }

}
