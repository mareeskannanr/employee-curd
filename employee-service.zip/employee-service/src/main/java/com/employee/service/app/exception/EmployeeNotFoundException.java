package com.employee.service.app.exception;

public class EmployeeNotFoundException extends AppException {

    public EmployeeNotFoundException() {
        super("Employee does not exists!");
    }

}
