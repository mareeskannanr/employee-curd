package com.employee.service.app.models;


import com.employee.service.app.utils.AppConstants;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue
    private UUID uuid;

    @Email(message = AppConstants.EMAIL_INVALID)
    @NotBlank(message = AppConstants.EMAIL_REQUIRED)
    private String email;

    @Column(name = "full_name")
    @NotBlank(message = AppConstants.EMAIL_REQUIRED)
    private String fullName;

    @JsonSerialize(using = ToStringSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate birthday;

    @ManyToOne
    @JoinColumn(name="department_id")
    private Department department;

    @Transient
    @JsonInclude
    private Long departmentId;


}
