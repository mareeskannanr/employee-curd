package com.employee.service.app.services;

import com.employee.service.app.exception.AppException;
import com.employee.service.app.exception.EmployeeNotFoundException;
import com.employee.service.app.models.Department;
import com.employee.service.app.models.Employee;
import com.employee.service.app.repositories.DepartmentRepository;
import com.employee.service.app.repositories.EmployeeRepository;
import com.employee.service.app.utils.AppConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public Department saveDepartment(Department department) {

        if(departmentRepository.findByName(department.getName()) != null) {
            throw new AppException(AppConstants.DEPARTMENT_EXISTS);
        }

        return departmentRepository.save(department);
    }

    @Override
    public Employee saveEmployee(Employee employee) {

        Employee previousEmployee;

        if(employee.getUuid() != null) {
            previousEmployee = employeeRepository.getOne(employee.getUuid());
            if(previousEmployee == null) {
                throw new EmployeeNotFoundException();
            }
        }

        previousEmployee = employeeRepository.findByEmail(employee.getEmail());
        if(previousEmployee != null && (employee.getUuid() == null || !previousEmployee.getUuid().equals(employee.getUuid()))) {
            throw new AppException(AppConstants.EMAIL_EXISTS);
        }

        return employeeRepository.save(employee);
    }

    @Override
    public Employee getEmployeeById(UUID uuid) {
        Employee employee = employeeRepository.getOne(uuid);

        if(employee == null) {
            throw new EmployeeNotFoundException();
        }

        return employeeRepository.getOne(uuid);
    }

    @Override
    public void deleteEmployee(UUID uuid) {
        Employee employee = employeeRepository.getOne(uuid);

        if(employee == null) {
            throw new EmployeeNotFoundException();
        }

        employeeRepository.delete(employee);
    }


}
