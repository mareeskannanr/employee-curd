package com.employee.service.app.utils;


public class AppConstants {

    public static final String NAME_REQUIRED = "name is required";
    public static final String EMAIL_INVALID = "email is invalid";
    public static final String EMAIL_REQUIRED = "email is required";
    public static final String INVALID_POST_MSG = "object contains invalid data";
    public static final String INTERNAL_SERVER_ERROR_MSG = "sorry, something went wrong!";
    public static final String EMAIL_EXISTS = "email already exists";
    public static final String DEPARTMENT_EXISTS = "department name already exists";
    public static final String EMPLOYEE_NOT_EXISTS = "employee doesn't exists";

    public static final String API = "/api";
    public static final String DEPARTMENT_URL = "/department";
    public static final String EMPLOYEE_URL = "/employee";
    public static final String UUID = "uuid";
    public static final String EMPLOYEE_ID_URL = EMPLOYEE_URL + "/{" + UUID + "}";

}