self.__precacheManifest = [
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "20f01824cc90f520200f",
    "url": "/static/js/main.8e48a9fc.chunk.js"
  },
  {
    "revision": "b22e907a4985b4e491a1",
    "url": "/static/js/2.ce77fafa.chunk.js"
  },
  {
    "revision": "20f01824cc90f520200f",
    "url": "/static/css/main.6002b5a5.chunk.css"
  },
  {
    "revision": "b22e907a4985b4e491a1",
    "url": "/static/css/2.e2839ca8.chunk.css"
  },
  {
    "revision": "495e49cf01efabd45b814f002e9b2533",
    "url": "/index.html"
  }
];