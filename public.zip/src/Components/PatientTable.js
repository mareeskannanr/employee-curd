import React, { Component } from 'react';
import axios from '../axios';

import PatientModal from './PatientModal';

export default class PatientTable extends Component {

    headerArray = ["ID", "Name", "Sex", "DOB"];
    state = {
        patients: [],
        filteredPatients: [],
        open: false,
        searchValue: ''
    };

    componentDidMount() {
        this.getAllPatients();
    }

    getAllPatients() {
        axios.get('/api/patients')
            .then(result => this.setState({patients: result.data, filteredPatients: result.data}))
            .catch(err => console.error(err.response));
    }

    patientClick(id) {
        alert(id);
    }

    searchByName() {
        let name = this.state.searchValue;

        if(!name) {
            return this.setState({
                filteredPatients: [...this.state.patients]
            });
        }

        let filteredData = this.state.filteredPatients.filter(item => item.name.toLowerCase().indexOf(name.toLowerCase()) === 0);
        return this.setState({
            filteredPatients: filteredData
        });
    }

    openPatientModal() {
        this.setState({open: true}); 
    }

    closeModal() {
        this.setState({open: false}); 
        this.getAllPatients();
    }

    render() {
        return (
        <div className="row">
            {this.state.open && <PatientModal closeModal={() => this.closeModal()} />}
            <div className="row" style={{width: "80vw"}}>
                <div className="col-12 form-inline" style={{marginBottom: "20px", marginTop: "20px"}}>
                    <input type="text" style={{"width": "250px"}} value={this.state.searchValue} className="form-control" placeholder="Enter Name" onChange={e => this.setState({searchValue: e.target.value})} />&nbsp;&nbsp;
                    <button type='button' className='btn btn-info' onClick={() => this.searchByName()} disabled={!this.state.searchValue}>
                        <span className='fas fa-search'></span> Search
                    </button>&nbsp;&nbsp;
                    <button type='button' className='btn btn-danger' onClick={() => this.setState({searchValue: '', filteredPatients: [...this.state.patients]})}>
                        <span className='fas fa-redo'></span> Reset
                    </button>&nbsp;&nbsp;
                    <button type="button" className="btn btn-success float-right" onClick={() => this.openPatientModal()}>
                        <span className="fas fa-plus"></span> Patient
                    </button>
                </div>
                <div className="col-12">
                    <table className="table table-striped">
                        <thead className="table-dark">
                            <tr>
                                {this.headerArray.map(header => <th key={header}>{header}</th>)}
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.filteredPatients.map((row, index) =>
                                    <tr key={index} onClick={() => this.patientClick(row.id)}>
                                        <td>{row.id}</td>
                                        <td>{row.name}</td>
                                        <td>{row.sex}</td>
                                        <td>{row.dob}</td>
                                    </tr>
                                )    
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        );
    }

}