package com.study.scheduling.app.controller;

import com.study.scheduling.app.service.UIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/api")
public class UIRestCtrl {

    @Autowired
    private UIService uiService;

    @GetMapping("/rooms")
    public ResponseEntity getAllRooms() {
        return ResponseEntity.ok(uiService.getAllRooms());
    }

    @GetMapping("/doctors")
    public ResponseEntity getAllDoctors() {
        return ResponseEntity.ok(uiService.getAllDoctors());
    }

    @GetMapping("/patients")
    public ResponseEntity getAllPatients() {
        return ResponseEntity.ok(uiService.getAllPatients());
    }

}
