package com.study.scheduling.app.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.study.scheduling.app.exception.AppException;
import com.study.scheduling.app.model.Doctor;
import com.study.scheduling.app.model.Patient;
import com.study.scheduling.app.model.Room;
import com.study.scheduling.app.model.StudySchedule;
import com.study.scheduling.app.model.dto.ScheduleDTO;
import com.study.scheduling.app.repository.DoctorRepository;
import com.study.scheduling.app.repository.PatientRepository;
import com.study.scheduling.app.repository.RoomRepository;
import com.study.scheduling.app.repository.ScheduleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CommonUtils {

    private final static Logger logger = LoggerFactory.getLogger(CommonUtils.class);

    public static void setupRooms(RoomRepository roomRepository) {
        roomRepository.save(new Room(1L, "Room No.1"));
        roomRepository.save(new Room(2L, "Room No.2"));
        roomRepository.save(new Room(3L, "Room No.3"));
        roomRepository.save(new Room(4L,"Room No.4"));
        roomRepository.save(new Room(5L,"Room No.5"));
        logger.debug("Rooms Data Setup Done!");
    }

    public static void setupDoctors(DoctorRepository doctorRepository) {
        doctorRepository.save(new Doctor(1L,"Dr. Marry"));
        doctorRepository.save(new Doctor(2L,"Dr. Ani"));
        doctorRepository.save(new Doctor(3L,"Dr. Mathews"));
        doctorRepository.save(new Doctor(4L,"Dr. John"));
        doctorRepository.save(new Doctor(5L,"Dr. Paul"));
        logger.debug("Doctors Data Setup Done!");
    }

    public static Patient getPatient(ScheduleDTO schedule, PatientRepository patientRepository) {
        Optional<Patient> patientOptional = patientRepository.findById(schedule.getPatientId());

        if(!patientOptional.isPresent()) {
            throw new AppException(AppConstants.PATIENT_NOT_EXISTS);
        }

        return patientOptional.get();
    }

    public static Room getRoom(ScheduleDTO schedule, RoomRepository roomRepository) {
        Optional<Room> roomOptional = roomRepository.findById(schedule.getRoomId());
        if(!roomOptional.isPresent()) {
            throw new AppException(AppConstants.ROOM_NOT_EXISTS);
        }

        return roomOptional.get();
    }

    public static Doctor getDoctor(ScheduleDTO schedule, DoctorRepository doctorRepository) {
        Optional<Doctor> doctorOptional = doctorRepository.findById(schedule.getDoctorId());
        if(!doctorOptional.isPresent()) {
            throw new AppException(AppConstants.DOCTOR_NOT_EXISTS);
        }

        return doctorOptional.get();
    }

}
