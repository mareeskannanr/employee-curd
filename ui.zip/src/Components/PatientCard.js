import React from 'react';

const PatientCard = props => (
    <div className="card" style={{'width': '100vw'}}>
        <div className="card-header">
            <h3><span className='fas fa-user'></span> Patient Details</h3>
        </div>
        <div className="card-body">
            <div className='row'>
                {
                    props.patient.id && <div className='col-3 form-group'>
                        <label>ID</label>
                        <input className='form-control' value={props.patient.id} disabled />
                    </div>
                }
                {
                    props.patient.name && <div className='col-3 form-group'>
                        <label>Name</label>
                        <input className='form-control' value={props.patient.name} disabled />
                    </div>
                }
                {
                    props.patient.sex && <div className='col-3 form-group'>
                        <label>Sex</label>
                        <input className='form-control' value={props.patient.sex} disabled />
                    </div>
                }
                {
                    props.patient.dob && <div className='col-3 form-group'>
                        <label>DOB</label>
                        <input className='form-control' value={props.patient.dob} disabled />
                    </div>
                }
            </div>
        </div> 
    </div>
);

export default PatientCard;