import React from 'react';

const ScheduleCard = props => (
    <div className="card" style={{'width': '100vw'}}>
        <div className="card-header">
            <h3><span className='fas fa-stethoscope'></span> Schedule Details</h3>
        </div>
        <div className="card-body">
            <div className='row'>
                <div className='col-3 form-group'>
                    <label>Docotor</label>
                    <select value={props.schedule.doctorId} className="form-control" onChange={e => props.onChange('doctorId', e.target.value)} disabled={props.disable}>
                        <option value=''></option>
                        {props.doctors.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
                    </select>
                </div>
                <div className='col-3 form-group'>
                    <label>Room</label>
                    <select value={props.schedule.roomId} className="form-control" onChange={e => props.onChange('roomId', e.target.value)} disabled={props.disable}>
                        <option value={''}></option>
                        {props.rooms.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
                    </select>
                </div>
            </div>
        </div> 
    </div>
);

export default ScheduleCard;