import React from 'react';
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";

const StudyCard = props => (
    <div className="card" style={{'width': '100vw'}}>
        <div className="card-header">
            <h3><span className='fas fa-notes-medical'></span> Study Details</h3>
        </div>
        <div className="card-body">
            <div className='row'>
                <div className='col-4 form-group'>
                    <label>Description</label>
                    <textarea className='form-control' value={props.schedule.description} onChange={e => props.onChange('description', e.target.value)} required  disabled={props.disable}></textarea>
                </div>
                <div className='col-4 form-group'>
                    <label>Planned Start Time</label><br />
                    <DatePicker selected={props.schedule.plannedStartTime} onChange={time => props.onChange('plannedStartTime', time)} showTimeSelect className="form-control" dateFormat="Pp" required  disabled={props.disable} />
                </div>
                <div className='col-4 form-group'>
                    <label>Estimated End Time</label><br />
                    <DatePicker selected={props.schedule.estimatedEndTime} onChange={time => props.onChange('estimatedEndTime', time)} showTimeSelect className="form-control" dateFormat="Pp" required  disabled={props.disable} />
                </div>
            </div>
        </div> 
    </div>
);

export default StudyCard;