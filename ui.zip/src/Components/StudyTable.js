import React, { Component } from 'react';
import { withRouter } from 'react-router';
import axios from '../axios';

class StudyTable extends Component {

    headerArray = ["ID", "Patient Name", "Room Name", "Doctor Name", "Status"];
    status = ['', 'Planned', 'In Progress', 'Finished'];
    state = {
        schedules: [],
        filteredSchedules: [],
        search: {
            patient: '',
            doctor: '',
            status: ''
        }
    };

    componentDidMount() {
        this.getAllSchedules();
    }

    getAllSchedules() {
        axios.get('/api/schedules')
            .then(result => this.setState({schedules: result.data, filteredSchedules: result.data}))
            .catch(err => console.error(err.response));
    }

    gotoStudy(id) {
        this.props.history.push({
            pathname: `/study/${id}`
        });
    }

    search(key, value) {
        let search = {...this.state.search};
        search[key] = value;
        if(!search.patient && !search.doctor && !search.status) {
            return this.setState({
                filteredSchedules: [...this.state.schedules]
            });
        }

        let filteredSchedules = this.state.schedules.filter(item => {

            let patientFlag = true;
            if(search.patient && item[1].toLowerCase().indexOf(search.patient.toLowerCase()) !== 0) {
                patientFlag = false;
            }

            let doctorFlag = true;
            if(search.doctor && item[3].toLowerCase().indexOf(search.doctor.toLowerCase()) !== 0) {
                doctorFlag = false;
            }

            let statusFlag = true;
            if(search.status && item[4].toLowerCase().indexOf(search.status.toLowerCase()) !== 0) {
                statusFlag = false;
            }

            return patientFlag && doctorFlag && statusFlag;

        });

        return this.setState({search, filteredSchedules});
    }

    render() {
        return (
            <div className="col-12">
                <div className="col-12 form-inline clearfix" style={{marginBottom: "20px", marginTop: "20px"}}>
                    <div className='col-4 form-group'>
                        <div className="input-group mb-3">
                            <div className="input-group-prepend">
                                <span className="input-group-text fas fa-search"></span>
                            </div>
                            <input type="text" value={this.state.search.patient} className="form-control" placeholder="Enter Patient Name" onChange={e => this.search('patient', e.target.value)} />
                        </div>
                    </div>
                    <div className='col-4 form-group'>
                        <div className="input-group mb-3">
                            <div className="input-group-prepend">
                                <span className="input-group-text fas fa-search"></span>
                            </div>
                            <input type="text" value={this.state.search.doctor} className="form-control" placeholder="Enter Doctor Name" onChange={e => this.search('doctor', e.target.value)} />
                        </div>
                    </div>
                    <div className='col-4 form-group'>
                        <div className="input-group mb-3">
                            <div className="input-group-prepend">
                                <span className="input-group-text fas fa-search"></span>
                            </div>
                            <select value={this.state.search.status} className="form-control" onChange={e => this.search('status', e.target.value)}>
                                {this.status.map(item => <option key={item} value={item}>{item}</option>)}
                            </select>
                        </div>
                    </div>
                </div>
                <div className="col-12">
                    <table className="table table-striped">
                        <thead className="table-dark">
                            <tr>
                                {this.headerArray.map(header => <th key={header}>{header}</th>)}
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.filteredSchedules.map((row, index) =>
                                    <tr key={index} onClick={() => this.gotoStudy(row[0])}>
                                        <td>{row[0] || ''}</td>
                                        <td>{row[1] || ''}</td>
                                        <td>{row[2] || ''}</td>
                                        <td>{row[3] || ''}</td>
                                        <td>{row[4] || ''}</td>
                                    </tr>
                                )    
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }

}

export default withRouter(StudyTable);